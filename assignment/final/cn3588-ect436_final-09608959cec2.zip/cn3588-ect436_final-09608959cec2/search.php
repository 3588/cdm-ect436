<?php
/**
 * Created by PhpStorm.
 * User: junjun
 * Date: 15-7-15
 * Time: ����10:41
 */
include_once("class/database.php"); // for database class
$access = new Access();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Search articles</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Le styles -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <style type="text/css">
        body {
            padding-top: 20px;
            padding-bottom: 40px;
        }

        /* Custom container */
        .container-narrow {
            margin: 0 auto;
            max-width: 700px;
        }
        .container-narrow > hr {
            margin: 30px 0;
        }

        /* Main marketing message and sign up button */
        .jumbotron {
            margin: 60px 0;
            text-align: center;
        }
        .jumbotron h1 {
            font-size: 72px;
            line-height: 1;
        }
        .jumbotron .btn {
            font-size: 21px;
            padding: 14px 24px;
        }

        /* Supporting marketing content */
        .marketing {
            margin: 60px 0;
        }
        .marketing p + h4 {
            margin-top: 28px;
        }
    </style>
    <link href="assets/css/bootstrap-responsive.css" rel="stylesheet">

    <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="assets/js/html5shiv.js"></script>
    <![endif]-->

    <!-- Fav and touch icons -->
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
    <link rel="shortcut icon" href="assets/ico/favicon.png">
</head>

<body>

<div class="container-narrow">

    <div class="masthead">
        <ul class="nav nav-pills pull-right">
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="search.php">Search</a></li>
            <li><a href="admin.php">Admin</a></li>
        </ul>
        <h3 class="muted">ECT 436 - Final</h3>
    </div>


    <hr>

    <div class="jumbotron">
        <h1>Search articles</h1>
        <form role="form" action="search.php?action=title" method="post">
            <div class="form-group">
                <label for="exampleInputEmail1">title keyword</label>
                <input type="text" class="form-control" id="inputSuccess1" value="" name="keyword">
            </div>

            <button type="submit" class="btn btn-default" name="submit">Search</button>
        </form>

        <form role="form" action="search.php?action=articles" method="post">
            <div class="form-group">
                <label for="exampleInputEmail1">articles keyword</label>
                <input type="text" class="form-control" id="inputSuccess1" value="" name="keyword">
            </div>
            <button type="submit" class="btn btn-default" name="submit">Search</button>
        </form>

    </div>

    <hr>
    <?php
    if(isset($_GET['action'])){?>
    <div class="row-fluid marketing">
        <div class="span12">
        <?php
        $keyword = $_POST['keyword'];

        switch ($_GET['action']){
            case 'title':
                $sql="select * from articles where title LIKE '%$keyword%'";
                break;
            case 'articles':
                $sql="select * from articles where article LIKE '%$keyword%'";
                break;
            default:
                echo "ERROR on action";

        }
        $query = $access->query($sql);
        while ($access->fetch_row($query)) {
            ?>
          <a href="view.php?id=<?= $access->result($query, 1) ?>" target="_blank">  <h4><?= $access->result($query, 2) ?> @ <?php $cid=$access->result($query, 4);
                $sql="select * from categories WHERE id = $cid";
                $query2=$access->query($sql);
                echo  $access->result($query2,2);
                ?></h4></a>
            <p><?= $access->result($query, 3) ?></p>
            <?php
        }?>
        </div>
    </div><?php
    }
    else{}
    ?>

    <hr>

    <div class="footer">
        <p>&copy; Junjun 2015 | <a href="http://ectweb.cs.depaul.edu/jhuang50/ect436/final/">ECTWEBSITE</a> </p>
    </div>

</div> <!-- /container -->

<!-- Le javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="assets/js/jquery.js"></script>
<script src="assets/js/bootstrap-transition.js"></script>
<script src="assets/js/bootstrap-alert.js"></script>
<script src="assets/js/bootstrap-modal.js"></script>
<script src="assets/js/bootstrap-dropdown.js"></script>
<script src="assets/js/bootstrap-scrollspy.js"></script>
<script src="assets/js/bootstrap-tab.js"></script>
<script src="assets/js/bootstrap-tooltip.js"></script>
<script src="assets/js/bootstrap-popover.js"></script>
<script src="assets/js/bootstrap-button.js"></script>
<script src="assets/js/bootstrap-collapse.js"></script>
<script src="assets/js/bootstrap-carousel.js"></script>
<script src="assets/js/bootstrap-typeahead.js"></script>

</body>
</html>

