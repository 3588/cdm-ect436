<?php
if($_COOKIE['admin']==null||!isset($_COOKIE['admin'])){
    echo "ERROR";
}
else {
    /**
     * Created by PhpStorm.
     * User: junjun
     * Date: 15-7-15
     * Time: ����12:12
     */
    $sql = "select * from categories ";
    $access = new Access();
    $query = $access->query($sql);
    while ($access->fetch_row($query)) {
        ?>
        <div class="box-content">
            <form role="form" action="admin.php?action=updatecategories" method="post">
                <div class="form-group">
                    <label for="exampleInputEmail1">category</label>
                    <input type="text" class="form-control" id="inputSuccess1" value="<?= $access->result($query, 2) ?>"
                           name="category">
                </div>
                <input type="hidden" value="<?= $access->result($query, 1); ?>" name="id">
                <button type="submit" class="btn btn-default" name="submit">
                    update <?= $access->result($query, 2) ?></button>
                <button type="submit" class="btn btn-default" name="delete">
                    delete  <?= $access->result($query, 2) ?></button>
            </form>
        </div>

        <?php
    }?>
<label>ADD categories-don't use the same categories name </label>
<div class="box-content">
    <form role="form" action="admin.php?action=addcategories" method="post">
        <div class="form-group">
            <label for="exampleInputEmail1">categories</label>
            <input type="text" class="form-control" id="inputSuccess1" value="" name="category">
        </div>
        <button type="submit" class="btn btn-default" name="submit">ADD</button>
    </form>
</div>
<?php
}
?>
