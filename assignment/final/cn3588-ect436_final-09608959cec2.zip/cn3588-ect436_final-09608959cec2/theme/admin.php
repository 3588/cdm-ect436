<?php
if($_COOKIE['admin']==null||!isset($_COOKIE['admin'])){
    echo "ERROR";
}
else{?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <title>ect436 admin</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">

        <!-- Le styles -->
        <link href="assets/css/bootstrap.css" rel="stylesheet">
        <style>
            body {
                padding-top: 60px; /* 60px to make the container go all the way to the bottom of the topbar */
            }
        </style>
        <link href="assets/css/bootstrap-responsive.css" rel="stylesheet">

        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
        <script src="assets/js/html5shiv.js"></script>
        <![endif]-->

        <!-- Fav and touch icons -->
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
        <link rel="shortcut icon" href="assets/ico/favicon.png">
    </head>

    <body>

    <div class="navbar navbar-inverse navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container">
                <button type="button" class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="brand" href="#">ect436 admin control</a>
                <div class="nav-collapse collapse">
                    <ul class="nav">
                        <li class="active"><a href="admin.php">Home</a></li>
                        <li><a href="?users">Users</a></li>
                        <li><a href="?categories">Categories</a></li>
                        <li><a href="?articles">Articles</a></li>
                        <li><a href="admin.php?a=logout">Logout</a></li>
                    </ul>
                </div><!--/.nav-collapse -->
            </div>
        </div>
    </div>


    <div class="container">
        <?php
        if(isset($_GET['users'])){
            require_once("theme/admin_user.php");
        }
        elseif(isset($_GET['categories'])){
            require_once("theme/admin_categories.php");
        }
        elseif(isset($_GET['articles'])){
            require_once("theme/admin_articles.php");
        }
        elseif(isset($_GET['action'])) {
            $gourl = null;
            switch ($_GET['action']) {
                case 'updateuser':
                    $gourl="users";
                    if(isset($_POST['submit'])){
                    if ($_POST[pass] == null){
                        $sql = "update users set user='" . $_POST['user'] . "' where id=" . $_POST[id];
                    }
                    else $sql = "update users set user='" . $_POST['user'] . "' , pass = '" . md5($_POST['pass']) . "' where id=" . $_POST['id'];
                    }
                    else {
                        $sql = "DELETE * FROM users WHERE id = " . $_POST['user'] . "";
                    }
                    break;
                case 'adduser':
                    $gourl="users";
                    $sql = "INSERT INTO users(user,pass) VALUES('" . $_POST['user'] . "' , '" . $_POST['pass'] . "')";
                    break;
                case 'updatecategories':
                   $gourl="categories";
                    if(isset($_POST['submit']))
                        $sql ="update categories set category='" . $_POST['category'] . "' where id=" . $_POST['id'];
                    else
                        $sql="DELETE * FROM categories WHERE id = ".$_POST['id']."";

                    break;
                case 'addcategories':
                    $gourl="categories";
                    $sql = "INSERT INTO categories(category) VALUES('" . $_POST['category'] . "')";
                    break;
                case 'updatearticles':
                    $gourl="articles";
                    if(isset($_POST['submit']))
                        $sql ="update articles set title='" . $_POST['title'] . "' , article = '" . $_POST['article'] . "' where id=" . $_POST['id'];
                    elseif(isset($_POST['updatecategories']))
                          $sql = "update articles set category='" . $_POST['category'] . "' where id=" . $_POST[id];
                    else
                        $sql="DELETE * FROM articles WHERE id = ".$_POST['id']."";

                    break;
                case 'addarticles':
                    $gourl="articles";
                    $sql = "INSERT INTO articles(title,article,category) VALUES('" . $_POST['title'] . "' , '" . $_POST['article'] . "' , '".$_POST['category']."' )";
                    echo $sql;
                    break;

                default:
                    echo "ERROR on action";
            }
            $query = $access->query($sql);
            if ($query) {
            echo "<script language=\"javascript\">";
            echo "document.location=\"admin.php?".$gourl."\"";
            echo "</script>";
        }            else
                echo "ERROR action";
        }
        else {
            echo "<h1>Hello ".$_COOKIE["user"]."</h1>
        <p><b>Simple Blog and CMS</b><br>categories Management<br> User Management <br> Article Center</p>
        <p>User access database.</p>
        <p>Created by Junjun Huang @ CDM</p>";
            }
    ?>
    </div> <!-- /container -->

    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap-transition.js"></script>
    <script src="assets/js/bootstrap-alert.js"></script>
    <script src="assets/js/bootstrap-modal.js"></script>
    <script src="assets/js/bootstrap-dropdown.js"></script>
    <script src="assets/js/bootstrap-scrollspy.js"></script>
    <script src="assets/js/bootstrap-tab.js"></script>
    <script src="assets/js/bootstrap-tooltip.js"></script>
    <script src="assets/js/bootstrap-popover.js"></script>
    <script src="assets/js/bootstrap-button.js"></script>
    <script src="assets/js/bootstrap-collapse.js"></script>
    <script src="assets/js/bootstrap-carousel.js"></script>
    <script src="assets/js/bootstrap-typeahead.js"></script>

    </body>
    </html>

<?php
}?>