<?php
if($_COOKIE['admin']==null||!isset($_COOKIE['admin'])){
    echo "ERROR";
}
else {
    /**
     * Created by PhpStorm.
     * User: junjun
     * Date: 15-7-15
     * Time: ����12:12
     */
    $sql = "select * from users ";
    $access = new Access();
    $query = $access->query($sql);
    while ($access->fetch_row($query)) {
        ?>
        <div class="box-content">
            <form role="form" action="admin.php?action=updateuser" method="post">
                <div class="form-group">
                    <label for="exampleInputEmail1">username</label>
                    <input type="text" class="form-control" id="inputSuccess1" value="<?= $access->result($query, 2) ?>"
                           name="user">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">password-leave if you don't want change</label>
                    <input type="password" class="form-control" id="inputSuccess1" value="" name="pass">
                </div>
                <input type="hidden" value="<?= $access->result($query, 1); ?>" name="id">
                <button type="submit" class="btn btn-default" name="submit">
                    update <?= $access->result($query, 2) ?></button>
                <button type="submit" class="btn btn-default" name="delete">
                    delete  <?= $access->result($query, 2) ?></button>
            </form>
        </div>

        <?php
    }?>
<label>ADD USER-don't use the same username </label>
<div class="box-content">
    <form role="form" action="admin.php?action=adduser" method="post">
        <div class="form-group">
            <label for="exampleInputEmail1">username</label>
            <input type="text" class="form-control" id="inputSuccess1" value="" name="user">
        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">password</label>
            <input type="password" class="form-control" id="inputSuccess1" value="" name="pass">
        </div>
        <button type="submit" class="btn btn-default" name="submit">ADD</button>
    </form>
</div>
<?php
}
?>
