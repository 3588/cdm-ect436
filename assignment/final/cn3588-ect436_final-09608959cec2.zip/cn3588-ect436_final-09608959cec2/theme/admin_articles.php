<script src="//cdn.ckeditor.com/4.5.1/standard/ckeditor.js"></script>
<?php
if($_COOKIE['admin']==null||!isset($_COOKIE['admin'])){
    echo "ERROR";
}
else {
    /**
     * Created by PhpStorm.
     * User: junjun
     * Date: 15-7-15
     * Time: ����12:12
     */
    $sql = "select * from articles ";
    $access = new Access();
    $query = $access->query($sql);
    while ($access->fetch_row($query)) {
        ?>
        <div class="box-content">
            <form role="form" action="admin.php?action=updatearticles" method="post">
                <label for="exampleInputEmail1">article ID : <?= $access->result($query, 1) ?></label>
                <div class="form-group">
                    <label for="exampleInputEmail1">title</label>
                    <input type="text" class="form-control" id="inputSuccess1" value="<?= $access->result($query, 2) ?>"
                           name="title">
                </div>
                <div class="form-group">
                <label for="exampleInputEmail1">article</label>
                    <textarea class="ckeditor" name="article" rows="10" cols="80"><?= $access->result($query, 3) ?></textarea>
          </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">category</label>
                        <input type="text" class="form-control" id="inputSuccess1" value="<?php $cid=$access->result($query, 4);
                         $sql="select * from categories WHERE id = $cid";
                            $query2=$access->query($sql);
                        echo  $access->result($query2,2);
                        ?>" >
                    </div>
                <div class="form-group">
                <label for="exampleInputEmail1">update category</label>
                <select class="category" name="category">
                    <?php
                    $sql="select * from categories";
                    $query2=$access->query($sql);
                    while($access->fetch_row($query2))
                    {
                        echo "<option value=\"";
                        echo $access->result($query2,1);
                        echo "\">";
                        echo $access->result($query2,2);
                        echo "</option>";
                    }
                    ?>
                </select>
                    </div>
                <input type="hidden" value="<?= $access->result($query, 1); ?>" name="id">
                <button type="submit" class="btn btn-default" name="submit">
                    update <?= $access->result($query, 2) ?></button>
                <button type="submit" class="btn btn-default" name="updatecategories">
                    update categories</button>
                <button type="submit" class="btn btn-default" name="delete">
                    delete  <?= $access->result($query, 2) ?></button>
            </form>
        </div>

        <?php
    }?>
<label>ADD article</label>
<div class="box-content">
    <form role="form" action="admin.php?action=addarticles" method="post">
        <div class="form-group">
            <label for="exampleInputEmail1">title</label>
            <input type="text" class="form-control" id="inputSuccess1" value="" name="title">
        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">article</label>
            <textarea class="ckeditor" name="article" rows="10" cols="80"></textarea>
            <label for="exampleInputEmail1">category</label>
            <select class="category" name="category">
                <?php
                $sql="select * from categories";
                $query=$access->query($sql);
                while($access->fetch_row($query))
                {
                    echo "<option value=\"";
                    echo $access->result($query,1);
                    echo "\">";
                    echo $access->result($query,2);
                    echo "</option>";
                }
                ?>
            </select>
        </div>
        <button type="submit" class="btn btn-default" name="submit">ADD</button>
    </form>
</div>
<?php
}
?>
