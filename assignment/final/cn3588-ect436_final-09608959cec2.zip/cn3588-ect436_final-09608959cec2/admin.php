<?php
/**
 * Created by PhpStorm.
 * User: junjun
 * Date: 15-7-15
 * Time: ����10:28
 */
if(!isset($_COOKIE["admin"])) $_COOKIE["admin"] = null; // for skip the error if didn't set cookie
if(!isset($_GET["a"])) $_GET["a"] = null; // for skip the error if didn't have get data
include_once("class/database.php"); // for database class
$access = new Access();
if($_COOKIE["admin"]=="21232f297a57a5a743894a0e4a801fc3"&&$_GET["a"]!="logout")//logined
{
    require_once("theme/admin.php");
}
elseif($_GET["a"]=="login") {
    $user=$_POST['user'];
    $pass=md5($_POST['pass']);
    $sql="select * from users where user = '$user' and pass = '$pass'";
    $query=$access->query($sql);
    if($access->result($query,2)!=null){
        setcookie("admin","21232f297a57a5a743894a0e4a801fc3", time()+3600*24, '/');
        setcookie("user","$user", time()+3600*24, '/');
        echo "<script language=\"javascript\">";
        echo "document.location=\"admin.php\"";
        echo "</script>";
    }
    else echo "Wrong password or username "."<a href=\"admin.php\">Login again</a>";

}
elseif($_GET["a"]=="logout") {
    setcookie("admin",null, time()+3600*24, '/');
    setcookie("user",null, time()+3600*24, '/');
    echo "<script language=\"javascript\">";
    echo "document.location=\"admin.php\"";
    echo "</script>";

}
else{
    require_once("theme/signin.html");
}