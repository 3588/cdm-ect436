<?php
error_reporting (E_ALL & ~E_NOTICE);
class Access
{
    var $conn;
    function Access()
    {
        $dsn="DRIVER=Microsoft Access Driver (*.mdb);DBQ=".realpath("../../Database/ect436.mdb");
        $this->conn=odbc_connect($dsn,"","",SQL_CUR_USE_ODBC );
    }
    function query($sql)
    {
        return odbc_exec($this->conn,$sql);
    }
    function num_fields($query)
    {
        return odbc_num_fields($query);
    }
    function fetch_row($query)
    {
        return odbc_fetch_row($query);
    }
    function result($query,$field)
    {
        return odbc_result($query,$field);
    }
}
?>   