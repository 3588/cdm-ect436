<?php
/**
 * Created by PhpStorm.
 * User: cxhjj_000
 * Date: 2015/6/29
 * Time: 18:09
 */


include_once("class/database.php");
$sql="select * from articles where category = '1'";
$access = new Access();
$query=$access->query($sql);
while($access->fetch_row($query))
{
    for($i=1;$i<=$access->num_fields($query);$i++)
        echo $access->result($query,$i);
    echo "<br>";
}




//$sql="update users set user='jhuang' , pass = '2e0f606e3090a123468fc634d794ea8d' where id=1";
//$sql="INSERT INTO users( user,pass) VALUES('test','test')";
$sql="select * from articles where title LIKE '123'";
$query=$access->query($sql);
if($query)
    echo "ok";