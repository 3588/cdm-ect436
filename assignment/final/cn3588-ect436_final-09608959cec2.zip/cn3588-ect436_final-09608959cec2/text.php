<script src="//cdn.ckeditor.com/4.5.1/basic/ckeditor.js"></script>
<textarea class="ckeditor" name="editor"></textarea>